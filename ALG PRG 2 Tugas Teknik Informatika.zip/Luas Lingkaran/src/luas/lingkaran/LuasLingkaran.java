/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luas.lingkaran;

/**
 *
 * @author notebook
 */
public class LuasLingkaran {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       double pi, r, a;
       r = 10.2; //radius lingkaran
       pi = 3.14; //pi, lingkaran
       a = pi*r*r; // menghitung luas
       System.out.print("Luas Lingkaran " + a);
    }
}
