/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elementterbesar;

/**
 *
 * @author M.Rizky Abdillah
 */
public class ElementTerbesar {

    /**
     * @Tugas TEKNIK INFORMATIKA
     */
    public static void main(String[] args) {
         double[] myList = {6.9, 3.9, 2.4, 7.5};

      // Mencetak semua array elemen
      for (int i = 0; i < myList.length; i++) {
         System.out.println(myList[i] + " ");
      }
      // Menjumlahkan semua elemen
      double total = 0;
      for (int i = 0; i < myList.length; i++) {
         total += myList[i];
      }
      System.out.println("Total Jumlah Adalah" + total);
      // Mencari elemen terbesar
      double max = myList[0];
      for (int i = 1; i < myList.length; i++) {
         if (myList[i] > max) max = myList[i];
      }
      System.out.println("Elemen terbesar adalah " + max);
   }   
}
