 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaperhitungan;

/**
 *
 * @author M,rizky Abdillah
 */
public class JavaPerhitungan {

    /**
     * Tugas Teknik Informatika
     */
    public static void main(String[] args) {
      int nilai1 =20;
      int nilai2 =5;
      int penjumlahan = nilai1+nilai2;
      int pengurangan = nilai1-nilai2;
      float pembagian = nilai1/nilai2;
      int perkalian = nilai1*nilai2;
      
      System.out.println("nilai 1 =" + nilai1);
       System.out.println("nilai 2 =" + nilai2);
        System.out.println("penjumlahan =" + penjumlahan);
         System.out.println("pengurangan =" + pengurangan);
          System.out.println("pembagian =" + pembagian);
           System.out.println("perkalian =" + perkalian);
     
          
    }
    
}
