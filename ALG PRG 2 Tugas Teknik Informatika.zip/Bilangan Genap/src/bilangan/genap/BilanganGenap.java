/*
 * Assalamualaikum Wr.Wb 
 * Tugas Teknik Informatika
 * jangan lupa baca bismillahirohmani rohhim.
 */
package bilangan.genap;

/**
 *
 * @author rizky anjass...
 */
public class BilanganGenap {

    
    public static void main(String[] args) {
        for(int i=1; i<=20;i++)
            if (i % 2 == 0){
                System.out.println(i + "");
            }
        
    }
    
}
